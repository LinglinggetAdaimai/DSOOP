public enum CommandWord {
    GO, HELP, QUIT, LOOK, UNKNOWN, BACK;
}
