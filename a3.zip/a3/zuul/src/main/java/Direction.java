public enum Direction {
    NORTH, EAST, WEST, SOUTH, UNKNOWN
}
