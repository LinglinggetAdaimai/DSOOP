rootProject.name = "sllist-gradle"

