package game;

public enum CommandWords {
    QUIT, GIVEUP, INFO, TWIST;
}
